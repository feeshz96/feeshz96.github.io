﻿function actionHtmlWindow(str) {
 var a =	new ActionHtmlWindow(str); return a;
}

